Łukasz Raszkiewicz, lr371594

Zadanie i wszystkie dodatki są zaimplementowane.